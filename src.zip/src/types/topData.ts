export type TopData = {
  url?: string;
  view?: string;
  unique?: string;
  percent?: number;
};
